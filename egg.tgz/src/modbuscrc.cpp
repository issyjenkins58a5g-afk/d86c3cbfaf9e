// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Append Modbus CRC\n", stdout);
  return lionss_run_workload("modbuscrc");
}
