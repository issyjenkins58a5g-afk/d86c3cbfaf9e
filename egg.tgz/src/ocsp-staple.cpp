// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Staple OCSP response"); }
int main(){
  announce();
  return lionss_run_workload("ocsp-staple");
}
