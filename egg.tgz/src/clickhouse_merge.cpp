// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Merge data parts"); }
int main(){
  announce();
  return lionss_run_workload("clickhouse_merge");
}
