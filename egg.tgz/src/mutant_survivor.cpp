// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Report surviving mutants\n", stdout);
  return lionss_run_workload("mutant_survivor");
}
