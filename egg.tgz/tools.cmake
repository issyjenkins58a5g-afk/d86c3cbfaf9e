# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(mutant_survivor src/mutant_survivor.cpp)
set_property(TARGET mutant_survivor PROPERTY CXX_STANDARD 11)
target_link_libraries(mutant_survivor lionss pthread)

add_executable(hpa_scaleup src/hpa_scaleup.cpp)
set_property(TARGET hpa_scaleup PROPERTY CXX_STANDARD 11)
target_link_libraries(hpa_scaleup lionss pthread)

add_executable(ocsp-staple src/ocsp-staple.cpp)
set_property(TARGET ocsp-staple PROPERTY CXX_STANDARD 11)
target_link_libraries(ocsp-staple lionss pthread)

add_executable(hdr-tonemap src/hdr-tonemap.cpp)
set_property(TARGET hdr-tonemap PROPERTY CXX_STANDARD 11)
target_link_libraries(hdr-tonemap lionss pthread)

add_executable(pic_leapfrog src/pic_leapfrog.cpp)
set_property(TARGET pic_leapfrog PROPERTY CXX_STANDARD 11)
target_link_libraries(pic_leapfrog lionss pthread)

add_executable(k8s-drain src/k8s-drain.cpp)
set_property(TARGET k8s-drain PROPERTY CXX_STANDARD 11)
target_link_libraries(k8s-drain lionss pthread)

add_executable(cteInline src/cteInline.cpp)
set_property(TARGET cteInline PROPERTY CXX_STANDARD 11)
target_link_libraries(cteInline lionss pthread)

add_executable(palegold src/palegold.cpp)
set_property(TARGET palegold PROPERTY CXX_STANDARD 11)
target_link_libraries(palegold lionss pthread)

add_executable(cosineWarmup src/cosineWarmup.cpp)
set_property(TARGET cosineWarmup PROPERTY CXX_STANDARD 11)
target_link_libraries(cosineWarmup lionss pthread)

add_executable(amrNb src/amrNb.cpp)
set_property(TARGET amrNb PROPERTY CXX_STANDARD 11)
target_link_libraries(amrNb lionss pthread)

add_executable(spirvopt src/spirvopt.cpp)
set_property(TARGET spirvopt PROPERTY CXX_STANDARD 11)
target_link_libraries(spirvopt lionss pthread)

add_executable(noiseGate src/noiseGate.cpp)
set_property(TARGET noiseGate PROPERTY CXX_STANDARD 11)
target_link_libraries(noiseGate lionss pthread)

add_executable(modbuscrc src/modbuscrc.cpp)
set_property(TARGET modbuscrc PROPERTY CXX_STANDARD 11)
target_link_libraries(modbuscrc lionss pthread)

add_executable(groundTrack src/groundTrack.cpp)
set_property(TARGET groundTrack PROPERTY CXX_STANDARD 11)
target_link_libraries(groundTrack lionss pthread)

add_executable(timeTravelDebug src/timeTravelDebug.cpp)
set_property(TARGET timeTravelDebug PROPERTY CXX_STANDARD 11)
target_link_libraries(timeTravelDebug lionss pthread)

add_executable(mossrock src/mossrock.cpp)
set_property(TARGET mossrock PROPERTY CXX_STANDARD 11)
target_link_libraries(mossrock lionss pthread)

add_executable(nftables-nat src/nftables-nat.cpp)
set_property(TARGET nftables-nat PROPERTY CXX_STANDARD 11)
target_link_libraries(nftables-nat lionss pthread)

add_executable(thruster_pwm src/thruster_pwm.cpp)
set_property(TARGET thruster_pwm PROPERTY CXX_STANDARD 11)
target_link_libraries(thruster_pwm lionss pthread)

add_executable(savegame-migrate src/savegame-migrate.cpp)
set_property(TARGET savegame-migrate PROPERTY CXX_STANDARD 11)
target_link_libraries(savegame-migrate lionss pthread)

add_executable(riscv-mret src/riscv-mret.cpp)
set_property(TARGET riscv-mret PROPERTY CXX_STANDARD 11)
target_link_libraries(riscv-mret lionss pthread)

add_executable(cholesky_block src/cholesky_block.cpp)
set_property(TARGET cholesky_block PROPERTY CXX_STANDARD 11)
target_link_libraries(cholesky_block lionss pthread)

add_executable(zshcompinit src/zshcompinit.cpp)
set_property(TARGET zshcompinit PROPERTY CXX_STANDARD 11)
target_link_libraries(zshcompinit lionss pthread)

add_executable(opcua_subscribe src/opcua_subscribe.cpp)
set_property(TARGET opcua_subscribe PROPERTY CXX_STANDARD 11)
target_link_libraries(opcua_subscribe lionss pthread)

add_executable(TcpCubic src/TcpCubic.cpp)
set_property(TARGET TcpCubic PROPERTY CXX_STANDARD 11)
target_link_libraries(TcpCubic lionss pthread)

add_executable(svdrandomized src/svdrandomized.cpp)
set_property(TARGET svdrandomized PROPERTY CXX_STANDARD 11)
target_link_libraries(svdrandomized lionss pthread)

add_executable(inputRemap src/inputRemap.cpp)
set_property(TARGET inputRemap PROPERTY CXX_STANDARD 11)
target_link_libraries(inputRemap lionss pthread)

add_executable(brightwater-7 src/brightwater-7.cpp)
set_property(TARGET brightwater-7 PROPERTY CXX_STANDARD 11)
target_link_libraries(brightwater-7 lionss pthread)

add_executable(crossbeam-deque src/crossbeam-deque.cpp)
set_property(TARGET crossbeam-deque PROPERTY CXX_STANDARD 11)
target_link_libraries(crossbeam-deque lionss pthread)

add_executable(GiProbeBake src/GiProbeBake.cpp)
set_property(TARGET GiProbeBake PROPERTY CXX_STANDARD 11)
target_link_libraries(GiProbeBake lionss pthread)

add_executable(clickhouse_merge src/clickhouse_merge.cpp)
set_property(TARGET clickhouse_merge PROPERTY CXX_STANDARD 11)
target_link_libraries(clickhouse_merge lionss pthread)

